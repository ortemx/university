let h = 40;

function setup() {
  createCanvas(windowWidth * 0.97,windowHeight * 0.97)
  background(255);
  fill(39, 35, 235);
  rectMode(CENTER);
  translate(width / 2, height / 2);
  drawAxis();
  zzz();

}

function drawAxis(){
  stroke(61, 60, 60);
  strokeWeight(2)    
  line(0, -height / 2, 0, height / 2);
  line(-width / 2, 0, width / 2, 0);

  noStroke();
  fill(255, 0, 0); 

  for ( let i = -width / 2; i < width / 2; i += h){
    ellipse(round(i / h)*h , 0, 5)
  }

  for ( let i = -height / 2; i < height / 2; i += h){
    ellipse(0, round(i / h)*h , 5)
  }  
  

  fill(166, 84, 25);  
  for ( let i = -width / 2; i < width / 2; i += h){
    text(round(i / h), i - h/2, h/2)
  }
  for ( let i = -height / 2; i < height / 2; i += h){
    if (-round(i / h) != 0){
      text(-round(i / h), 10, i + h/2) 
    }    
  }
}


function zzz(){
  
  for ( let x = -width / 2; x < width / 2; x += h/16){
    for ( let y = height / 2; y > -height / 2; y -= h/16){
      //===============================================================
      if ( x * y > 0){
        if (abs(x) + abs(y) < h){
          fill(0, 255, 0); 
        }
      } else {
        fill(0, 0, 255); 
      }

      //  in  fill(0, 255, 0); 
      //  out fill(0, 0, 255); 

      ellipse(x,y,2)      
    }
  }
}